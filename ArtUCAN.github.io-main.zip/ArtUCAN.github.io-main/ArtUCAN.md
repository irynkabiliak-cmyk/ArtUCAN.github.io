# UCAN Art — personalized starter for Iryna Yukent
- Bilingual: `index.html` (UA) and `en.html` (EN)
- No on‑site purchases; use Instagram/Etsy/PayPal links
- Replace email and social links with your own
- Add images to `/images` (webp ~1600px width) and update `src=` paths
- Publish:
  1) Upload all files to repo `2025`
  2) Settings → Pages → Deploy from branch (main / root)
  3) Open https://YOUR_USERNAME.github.io
